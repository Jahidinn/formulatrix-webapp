<?php 

$firstDate = $_GET['firstDate'];
$lastDate = $_GET['lastDate'];
$urutan = $_GET['urutan'];
$batas = $_GET['batas'];

echo $firstDate;
echo $lastDate;
echo $urutan;
echo $batas;
 ?>